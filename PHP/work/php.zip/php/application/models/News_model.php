<?php
/*Setting up your model*/
class News_model extends CI_Model{
	public function __construct()
	{
		$this->load->database();
	}

	//Query Builder을 사용하여 쿼리들의 모든 작업을 할 수 있다.
	//2개의 다른 쿼리를 수행한다. 모든 레코드를 가져올수 있고, slug를 통해 news item을 가져올 수 있다. 
	//$slug 변수에 알맞은 값을 넣는다
	public function get_news($slug = FALSE)
	{
	        if ($slug === FALSE)
	        {
	                $query = $this->db->get('news');
	                return $query->result_array();
	        }

	        $query = $this->db->get_where('news', array('slug' => $slug));
	        return $query->row_array();
	}

	//writes the data to the database.
	//use Query Builder class
	//use the input library to get the posted data
	public function set_news(){
		$this->load -> helper('url');
	
		$slug = url_title($this->input->post('title'), 'dash', TRUE);	//input library의 post메서드를 사용하여 데이터를 가져옴

		$data = array(
			'title' => $this->input ->post('title'),
			'slug' => $slug,
			'text' => $this->input ->post('text')
		);

		return $this->db->insert('news',$data);
	}
}	





?>
<html>
<head>
	<title>CodeIgniter 튜토리얼(Tutorial)</title>
</head>
<body>
<h1><?php echo $title ?><h1>
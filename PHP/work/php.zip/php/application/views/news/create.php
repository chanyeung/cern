<h2><?php echo $title ?></h2>

<?php
//report errors related to form validation
echo validation_errors(); ?>

<?php
// form_open() is provided by the form helper and renders the form element and adds extra functionality, like adding a hidden CSRF prevention field.
echo form_open('news/create') 
?>
<!-- <form action="http://localhost/index.php/news/create" method="post" accept-charset="utf-8"> -->

	<label for="title">Title</label>
	<input type="input" name="title"><br>

	<label for="text">Text</label>
	<textarea name="text"></textarea><br>

	<input type="submit" name="submit" value="Create news item">
</form>
<!-- 	<label for ="title">Title</label>
	<input type = "input" name="title" /><br />

	<label for="text">Text</label>
	<textarea name = "text"></textarea><br />

	<input type="submit" name="submit" value="Create news item" />
</form> -->
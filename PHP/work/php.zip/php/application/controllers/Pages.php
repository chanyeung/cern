<?php
class Pages extends CI_Controller {

        public function view($page = 'home')
        {
        	//페이지를 로드하기 전에 요청하는 페이지가 실제로 존재하는지 체크
        	if(!file_exists(APPPATH.'views/pages/'.$page.'.php')){
        		//Whoops, we don't have page for that!
        		show_404();
        	}
        	$data['title'] = ucfirst($page)	//First characte UpperCase첫번째 글자를 대문자로 가져옴

        	$this->load->view('template/header', $data);
        	$this->load->view('pages/'.$page, $data)
        	$this->load->view('template/footer', $data);
        }
}
?>
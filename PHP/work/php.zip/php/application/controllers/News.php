<?php
/*Display the news*/

class News extends CI_Controller{
	public function __construct(){
		parent :: __construct();
		$this -> load -> model('news_model');
	}

	public function index(){
		$data['news'] = $this -> news_model -> get_news();
		//views로 데이터를 넘기자
		$data['title'] = 'News archive';

		$this -> load -> view('templates/header', $data);
		$this -> load -> view('news/index', $data);
		$this -> load -> view('templates/footer');
	}

	public function view($slug = NULL){
		$data['news_item'] = $this -> news_model -> get_news($slug);

		/*
		Displat the news

		*/
		if(empty('news_item')){
			show_404();
		}
		$data['title'] = $data['news_item']['title'];

		$this->load->view('template/header', $data);
		$this->load->view('news/view', $data);
		$this->load->view('template/footer');
	}

	//1.check whether the form was submitted and whether the submitted data passed the validation rules.  -> use form validation library
	public function create(){
		$this->load->helper('form');
		$this -> load -> library('form_validation');

		$data['title'] = 'Create a news item';

		$this -> form_validation -> set_rules('title', 'Title', 'required');
		$this -> form_validation -> set_rules('text', 'text', 'required');

		if($this->form_validation -> run() === FALSE){
			$this-> load -> view('templates/header', $data);
			$this-> load -> view('news/create');
			$this-> load -> view('templates/footer');
		}else{
			$this->news_model->set_news();
			$this->load->view('news/success');

		}

	}
}
?>
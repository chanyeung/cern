<?php
if(preg_match("/php/i", "PHP is the web scripting language of choice.")){
    echo "A match was found.<br>";
}else{
    echo "A match was not found.";
}

$subject = 'coding everybody http://opentutorials.org egoing@naver.com 010-0000-0000';
// \w=문자[알파벳,숫자,언더라인]
//  + =1개이상
//  .=anycharater >> \.=.
//  \s=공백(space)
// ( ) = capturing, 배열이 1개에서 2개로 생김
// () = reverse reference, cappturing 
preg_match('~(http://\w+\.\w+)\s(\w+@\w+\.\w+)~',$subject, $match);
var_dump($match);
echo "<br>";
echo "homepage : ".$match[1];
echo "<br>";
echo "email:".$match[2];
?>
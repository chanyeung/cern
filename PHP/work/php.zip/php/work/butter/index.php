<?php
include '/home/pcy/www/html/butter/template/Template_.class.php';
$tpl = new Template_;
$tpl->define('index', 'index.tpl');
$tpl->assign(array(
        'title'=>'My WebServer',
        'content'=>'John Valentine',
        ));
$tpl->print_('index');
?>

<?php /* Template_ 2.2.8 2018/09/07 16:04:17 /home/pcy/www/html/butter/_template/index.tpl 000000269 */ ?>
<html>
   <head>
      <title><?php echo $TPL_VAR["title"]?></title>
   </head>
   <body>
   <?php echo $TPL_VAR["content"]?>'s First WebServer
   </body>
</html>
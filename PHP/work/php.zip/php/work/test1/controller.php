<?php
include 'AutoLoad.php';

foreach ($inputArr as $mall => $sqrArr) {			//roop['aucction']~['timon']
	$ch=$sqrArr['ch'];
	$myCurl = new MyCurl($ch);
	$myCurl->getEncoding();
	$curlResult = $myCurl->getResponse();

	foreach ($sqrArr as $key => $value) {			//roop auctionArr[ch]~[num] ~timon[ch]~[cat2]
		if($key!="ch"){
			$sort=$key;
			$matchArr = new MatchArr($value, $curlResult);
			$resultArr[$mall][$key]=$matchArr->getArr();
		}
	}
	$sort='name';
	//check POST['sort']
	if(isset($_POST['sort'])){
		$sort=$_POST['sort'];
		asort($resultArr[$mall][$sort]);
	}
	
	// echo "<xmp>";
	// print_r($resultArr[$mall]);
	// echo "</xmp>";
	$url = $urlArr[$mall];
	$matchArr->printArr($sort, $resultArr[$mall], $url);
}






//set & exec cURL
// $ch="http://browse.auction.co.kr/list?category=12230000";
// $myCurl = new MyCurl($ch);
// $curlResult = $myCurl->getResponse();

//scrap data with regular expresion
// $patternArr = array('name'=>'/>상품명 <\/span><span class="text--title">\s?(.*?)<!-- --> <\/span>/',
// 					'price'=>'/<strong class="text--price_seller">([\d,]*?)<\/strong>/',
// 					'num'=>'/ItemNo=(.*?)&SellerID=/',
// 					'num2'=>'/{"design":\d*,"viewModel":{"itemNo":"(.*?)",/');
// foreach ($patternArr as $key => $value) {
// 	//echo $key.'<br>';
// 	$matchArr = new MatchArr($value, $curlResult);
// 	$resultArr[$key]=$matchArr->getArr();
// }

//Change Array['product number']
// $resultArr['num'] = $matchArr->mergeArr($resultArr['num'],$resultArr['num2']);

// $sort='name';
// //check GET['sort']
// if(isset($_POST['sort'])){
// 	$sort=$_POST['sort'];
// 	asort($resultArr[$sort]);
// }

// $matchArr->printArr($sort, $resultArr);

















// echo "<xmp>";
// print_r($resultArr['price']);
// print_r($inputArr);
// echo "</xmp>";
?>
<?php
class MatchArr{
					//regularExpresion, cURL, resultArr[arrkey][0~N]
	function __construct($pattern, $curlResult){
		$this->pattern = $pattern;
		$this->curlResult = $curlResult;
		$this->matchAll();
	}

	function matchAll(){
		preg_match_all($this->pattern, $this->curlResult, $this->matchArr);
	}

	//replace ',' -> ''
	function getArr(){
		foreach ($this->matchArr[1] as $key => $value) {
			$value=str_replace(array(',', ' '), "", $value);
			$this->arr[$key]=$value;
		}
		return $this->arr;
	}

	/*function mergeArr($arr1, $arr2){
		foreach ($arr1 as $key => $value) {
			if($value==""){
				$arr1[$key]=$arr2[$key];
			}
		}
		return $arr1;
	}*/

	function printArr($sort,$resultArr, $url){
		echo "<br><table><tr>";
		foreach ($resultArr as $key => $value) {
			echo "<td>" . $key . "</td>";	
		}
		echo "</tr>";	
		
		foreach ($resultArr[$sort] as $idx => $value) {
			echo "<tr>";
			foreach ($resultArr as $key => $keyName) {
				echo "<td>";
				if($key=="num"){
					echo "<a href=" . $url .  $resultArr[$key][$idx] . ">";
					echo $resultArr[$key][$idx] . "</a></td>";
				}else{
					echo $resultArr[$key][$idx] . "</td>";
				}
			}
			echo "</tr>";
		}	
		echo "</table>";
	}
}
?>
<?php

//must first key define "ch"
$inputArr=array(
    "auction" => array(
        "ch" => "http://browse.auction.co.kr/list?category=12230000",
        "name" => '/>상품명 <\/span><span class="text--title">\s?(.*?)<!-- --> <\/span>/',
        "price" => '/<strong class="text--price_seller">([\d,]*?)<\/strong>/',
        "num" => '/dent.u002F25\?itemNo=(.*?)&methodCode=4470&Lis/'
    ),
    "street11" => array(
        "ch" => "http://www.11st.co.kr/category/DisplayCategory.tmall?method=getDisplayCategory2Depth&dispCtgrNo=1001819",
        "name" => '/<img src=".*?" alt="\s*([^{]+?)\s*" onerror/',
        "price" => '/<strong class="sale_price">(.*?[^\W])<\/strong>/',
        "num" => '/<img src="http:\/\/i\.011st.com\/ex_t\/R\/\d.*\/(.*?)\_(?:L300|B)/'
    ),
    "interpark" => array(
        "ch" => "http://shopping.interpark.com/best/main.do?&smid1=s_menu&smid2=best",
        "name" => '/<a href="\/product\/productInfo\.do\?prdNo=.*?&dispNo=.*class=".*>(.*?)<\/a>/',
        "price" => '/<span class="number">(.*?)<\/span>/',
        "num" => '/imgBox">\s.*?prdNo.*?(\d.*?)&dispNo=/'
     )
);

$urlArr=array(
    "auction" => "http://itempage3.auction.co.kr/DetailView.aspx?itemno=",
    "street11" => "http://www.11st.co.kr/product/SellerProductDetail.tmall?method=getSellerProductDetail&prdNo=",
    "interpark" => "http://shopping.interpark.com/product/productInfo.do?prdNo="
);
?>
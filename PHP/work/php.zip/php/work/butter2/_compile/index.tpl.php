<?php /* Template_ 2.2.8 2018/09/07 17:37:52 /home/pcy/www/html/butter2/_template/index.tpl 000000396 */ ?>
<html>
	<head>
		<title>board2</title>
	</head>
	<body>
		<h4>List</h4>

		<form action="view/signUp.html" method="POST">
			<button>Sign-Up</button>
		</form>
		
		<form action="view/logIn.html" method="POST">
			<button><?php echo $TPL_VAR["logIn"]?></button>
		</form>
	</body>
</html>
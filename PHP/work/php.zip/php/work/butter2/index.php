<?php
include 'AutoLoad.php';
include '/home/pcy/www/html/butter2/template/Template_.class.php';
$tpl = new Template_;
$tpl->define('index', 'index.tpl');	//define template file id to use
$tpl->assign(array(						//allocate value to template variable
        'logIn'=>'LogIn',
        'content'=>'John Valentine',
        ));
$tpl->print_('index');					//output



$conn=mysqli_connect("localhost", "local_user01","pcy621","pcy_db");
//연결 확인
if(mysqli_connect_errno()){
	printf("connect failed : %s\n", mysqli_connect_error());
	exit();
}
$sql="select * from study";
$result=mysqli_query($conn, $sql);

while($row=mysqli_fetch_array($result)){
        $list .= "<tr><td><a href=\"home.php?user_id={$row['user_id']}\">{$row['user_id']}</a></td>
        <td hidden><input type='hidden' name='primary_key' value=\"{$row['primary_key']}\"/></td>
        <td>{$row['user_name']}</td>
        <td>{$row['user_job']}</td>
        <td>{$row['user_sex']}</td></tr>";
}
echo "<table><tr style='background-color:lightblue;'><td>Id</td><td>Name</td><td>Job</td><td>Sex</td></tr>" . $list . "</table>";


?>

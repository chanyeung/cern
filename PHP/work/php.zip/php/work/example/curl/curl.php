<?php
$gmailId = "psg621";
$gmailPw = "*Opirus7";

/*example1 : transfer data by POST(simple)*/
/*$post_data = array(
	"sort"=> "price",
	"birthday" => "1991-06-21"
);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://pcy.nemo/test1/controller.php");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
$result = curl_exec($ch);

echo "<xmp>";
print_r($result);
echo "</xmp>";*/

/*example2 :  transfer data by POST(function)*/
/*function fetch_page($url, $param, $cookies, $referer_url){
	if(strlen(trim($referer_url))==0){
		$referer_url=$url;
	}
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
	// curl_setopt($ch, CURLOPT_POSTFIELDSIZE, 0);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	if($cookies&&$cookies!=""){
		curl_setopt($ch, CURLOPT_COOKIE, $cookies);
	}
	curl_setopt($ch, CURLOPT_HEADER, 1);	//get header value, because get cookie
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0(compatible;MSIE 5.01;WindowNT5.0");
	curl_setopt($ch, CURLOPT_REFERER, $referer_url);
	ob_start();
	$res=curl_exec($ch);
	$buffer=ob_get_contents();
	ob_end_clean();
	if(!$buffer){
		$returnVal = "Curl Fetch Error : ".curl_error($ch);
	}else{
		$returnVal = $buffer;
	}

	curl_close($ch);
	return $returnVal;
}*/

/*ex3 : transfer file*/
/*$post_data['data[0]']="@image/img_01.jpg";
$post_data['date[0]'] = "@image/img_02.jpg";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://www.example.com/upload.php");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
$postResult = curl_exec($ch);*/

/*ex4 : access https*/
/*$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://pcy.nemo/test1/controller.php");		//url address to access
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);	//like certification check, if true almost fail
//be careful, default value is true(it need access https)
curl_setopt($ch, CURLOPT_SSLVERSION, 3);	//SSL Version(it does'n need access to https)
curl_setopt($ch, CURLOPT_HEADER, 0);	//Ether print header or not
curl_setopt($ch, CURLOPT_POST, 1);	//Ether Post Get access or not
curl_setopt($ch, CURLOPT_POSTFIELDS, "sort=num&var2=str2");	//Post value[like get write]
curl_setopt($ch, CURLOPT_TIMEOUT, 30);	//time out value;
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	//get return value?
$result=curl_exec($ch);
curl_close($ch);
echo "<xmp>";
print_r($result);
echo "</xmp>";*/

/*ex5 : login Gmail using curl*/

//initial request with login data
$data = array('utf8' => '%E2%9C%93', 
'authenticity_token'=>'Up1tNokvSZGslTvpQ%2FGqDs%2FtB9g8pY0ezPLOLnvRvdFC343PAQQhc8XhihAWJtOvTTX%2FfYkmC%2FznnaLnOm23Dw%3D%3D',
'back_url'=>'http%3A%2F%2Fredmine.nemomall.co.kr%2Fprojects%2Fshoplinker_developer%2Fwiki',
'username'=>'pcy621',
'password'=>'cjfckd99',
'login'=>'%EB%A1%9C%EA%B7%B8%EC%9D%B8+%C2%BB'
);
$data = http_build_query($data, '', '&');
echo $data;
$src = "http://redmine.nemomall.co.kr/login";
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);	//cURL함수가 실행되는 최대 시간을 초단위로 지정
curl_setopt($ch, CURLOPT_HEADER, 0);	//true -> 출력에 헤더를 포함한다.
curl_setopt($ch, CURLOPT_POST, true);	//http POST를 수행하려면 true입력
//HTTP "POST"작업에 게시 할 전체 데이터입니다.  파일 유형은 '; type = mimetype'형식의 파일 이름을 따라 명시 적으로 지정할 수 있습니다. 이 매개 변수는 'para1 = val1 & para2 = val2 & ...'와 같은 URL 인코딩 된 문자열이나 필드 이름이 키이고 필드 데이터가 값인 배열로 전달할 수 있습니다. value가 배열이면 Content-Type 헤더가 multipart / form-data로 설정됩니다. 
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);	//"ㅣLocation:"헤더를 추적하려면 TRUE
curl_setopt($ch, CURLOPT_URL, $src);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);	//true - >exec의 결과를 스트링값으로 리턴받음, false일때는 화면에 출력해버림[변수에 담을 수 없음]
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/32.0.1700.107 Chrome/32.0.1700.107 Safari/537.36');
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');  //(curl_close 호출후)핸들을 닫을 때 모든 내부 쿠키를 저장할 파일의 이름
curl_setopt($ch, CURLOPT_COOKIEFILE, '/home/pcy/www/html/work/example/cookie.txt');  //쿠키 데이터가 들어있는 파일의 이름,쿠키파일은 Netscape형식이거나 파일에 덤프 된 일반 HTTP스타일 헤더 일 수 있다.
$res = curl_exec($ch);
curl_close($ch);
// result is Atom xml type, dom or xml pasing fuction use parse 
// echo "<xmp>";
echo $res;
// echo "</xmp>";

/*ex6 : get webPage using cURL*/
/*function get_content($url){
	$agent = 'Mozilla/4.0(compatible;MSIE 6.0;Windows NT 5.0';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 0);
	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
	curl_setopt($ch, CURLOPT_REFERER, "");
	curl_setopt($ch, CURLOPT_TIMEOUT, 3);
	$buffer = curl_exec($ch);
	$cinfo = curl_getinfo($ch);
	curl_close($ch);
	if($cinfo['http_code']!=200){
		return "http connect fail";
	}else{
		return $buffer;
	}
}
$url="http://www.naver.com";
$result=get_content($url);
echo "<xmp>";
print_r($result);
echo "</xmp>";*/


































?>
<?php
/*
https://login.ticketmonster.co.kr/user/loginform?return_url=
<strong id="userid_blind" class="">아이디</strong> -> userId
<strong id="pwd_blind" class="">비밀번호</strong>
*/

$username = 'myuser';
$password = 'mypass';
$loginUrl = 'https://login.ticketmonster.co.kr/user/loginform?return_url=';

//init curl
$ch = curl_init();

//Set the URL to work with
curl_setopt($ch, CURLOPT_URL, $loginUrl);

//ENABLE HTTP POST
curl_setopt($ch, CURLOPT_POST, 1);

//set the post parameters
curl_setopt($ch, CURLOPT_POSTFIELDS, 'userid=' .$username. '&pwd='.$password);		//Timon password id=pwd, name=password

//Handle cookies for the login
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');

//Setting CURLOPT_RETURNTRANSFER variable to 1 will force cURL
//not to print out the results of its query
//Insetead, it witt return the results as a string return value
//from curl_exec() instead of the usual true/false.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

//execute the request(the login)
$store = curl_exec($ch);

//the login is now done and you can continue to get the
//protected content

//set the URL to the protected file
curl_setopt($ch, CURLOPT_URL, 'https://login.ticketmonster.co.kr/user/buyInfo');

//execute the request
$content = curl_exec($ch);

curl_close($ch);

//save the data to disk
//preg_match_all('/(\w*구매내역)/', $content,	$matches);
echo "<xmp>";
print_r($content);
echo "</xmp>";
?>
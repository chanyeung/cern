<?php
	/*Setting Up cURL*/
	//First, we need to initiate the cURL handle
	$curl = curl_init("http://testing-ground.scraping.pro/textlist");

	//then, set CURLOPT_RETURNTRANSFER to TRUE to return the transfer page as a string rather than put it out directly:
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);

	/*Executing the request * Cheking for Errors*/
	//Now, start the request and perform an err check:
	$page = curl_exec($curl);

	if(curl_errno($curl))	//check for execution errors
	{
		echo 'Scrapper error : ' . curl_error($curl);
		exit;
	}
	
	/*Closing the Connection*/
	//to close the connection, type the following
	curl_close($curl);

	/*Extracting Only the Needed Patt and Printing It*/
	//After we have the page content, we may extract only the needed code snippet, under id="case_textlist";
	//$regex = '$lt;div id="case_textlist"&gt;(.*?)&lt;\/div&gt;/s';
	$regex = '/<div id="case_textlist">(.*?)<\/div>/s';
	if(preg_match($regex, $page, $list)){
		echo $list[0];
	}else{
		echo "Not found";
	}
?>
<?php

$urlArr=array(
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fb07e4c.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fb20c13.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fb78162.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fbf1a71.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fc859ed.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fd119e9.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fd9241e.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fe1fcf9.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fe5d012.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fea0213.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fead81d.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273ff0503f.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273ffe3eff.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9274014ca4c.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92740306b30.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9274051ecbc.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9274076063f.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92740b883d0.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741071700.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741d2d16d.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741e08383.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741e23e34.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741e43609.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741e6d65c.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741edad5b.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741f5c95d.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741fcfbb2.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92742055d75.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b927420c38fb.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92742201462.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b9273fe655p7.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92741dbfdo7.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b927420cd0c7.html",
"http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b92742201bs7.html"
);

foreach ($urlArr as $key => $value) {
	$ch = curl_init($value);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	$result = curl_exec($ch);

	//url에 ProductInfo라는 정보가 있으면
	if(preg_match('/ProductInfo/', $result)==1){
		echo "상품 이프문 진입 <br>";
		$inputArr["ProductInfo"]['ch'] = $value;
	}else if(preg_match('/Orderinfo/', $result)==1){
		echo "주문 이프문 진입 <br>";
		$inputArr["Orderinfo"]['ch'] = $value;
	}else if(preg_match('/ClaimInfo/', $result)==1){
		echo "클레임 이프문 진입 <br>";
		$inputArr["ClaimInfo"]['ch'] = $value;
	}else if(preg_match('/CsInfo/', $result)==1){
		echo "CS 이프문 진입 <br>";
		$inputArr["CsInfo"]['ch'] = $value;
	}else{
		continue;
	}
}

echo "<xmp>";
var_dump($inputArr['ProductInfo']['ch']);
echo "</xmp>";


?>
<?php
interface OutputInterface{
	public function load();
}

class SerializedArrayOutput implements OutputInterface{
	public function load(){
		return serialize($arrayOfData);
	}
}

class JsonStringOutput implements OutputInterface{
	public function load(){
		return json_encode($arrayOfData);
	}
}

class ArrayOutput implements OutputInterface{
	public function load(){
		return $arrayOfData;
	}
}

/*
위에서처럼 알고리즘을 캡슐화 함으로써, 다른 개발자들은 알고리즘을 사용하고 있는 코드에 영향을 주지 않고도 새로운 출력 형식을 추가할 수 있게 됩니다.

각각의 ‘출력’ 클래스들이 어떻게 OutputInterface를 구현하고 있는지 보이실 겁니다. 이러한 방식에는 두 가지 목적이 있는데, 첫 번째는 각각의 출력 클래스 구현체들이 준수해야하는 구현 규칙을 제공하는 것이고, 두 번째는 공통적으로 ‘OutputInterface’ 인터페이스를 구현함으로써 타입 힌팅을 통해 알고리즘을 사용하는 코드 쪽도 정확한 타입을 사용하도록 보장하는 것입니다.

아래 코드는 알고리즘을 사용하는 코드 쪽에서는 어떻게 구현해야 런타임에 동적으로 적당한 알고리즘을 설정하여 사용하게 할 수 있는지 예시를 보여줍니다.
*/






class SomeClient{
	private $output;

	public function setOutput(OutputInterface $outputType){
		$this->output = $outputType;
	}

	public function loadOutput(){
		return $this->output->load();
	}
}
/*
알고리즘을 사용하는 클래스는 ‘OutputInterface’ 타입의 프로퍼티를 가지고 있는데 이것은 런타임에 반드시 설정되어야 합니다. loadOutput() 메소드가 호출되면 프로퍼티의 load() 메소드를 호출함으로써 출력을 하게 됩니다.
*/





$client = new SomeClient();

// 배열 형태의 출력을 원한다면?
$client -> setOutput(new ArrayOutput());
$data = $client -> loadOutput();

// JSON 형태를 원한다면?
$client -> setOutput(new JsonStringOutput());
$data = $client -> loadOutput();








?>
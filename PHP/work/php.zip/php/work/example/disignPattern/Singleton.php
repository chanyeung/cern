<?php
class Singleton
{
	//static var sigleton $instance
	public static function getInstance(){
		static $instance = null;
		if(null === $instance){
			$instance = new static();
		}
		return $instance;
	}

	//define construct to protected
	protected function __construct(){
	}

	//limit private singleton instance to prohibit copy
	private function __clone(){
	}

	private function __wakeup(){
	}
}

class SingletonChild extends Singleton{
}

$obj = Singleton::getInstance();
var_dump($obj === Singleton::getInstance());	//bool(true)

$anotherObj = SingletonChild::getInstance();
var_dump($anotherObj === Singleton::getInstance());	//bool(false)

var_dump($anotherObj === SingletonChild::getInstance());	//bool(true)
/*
생성자 __construct()는 new 연산자를 사용해서 다른 곳에서 함부로 생성할 수 없도록 protected 로 제한되어 있습니다.
특수 매서드(Magic Method) __clone()은 clone 연산자를 사용해서 복제할 수 없도록 private 으로 제한되어 있습니다.
특수 매서드(Magic Method) __wakeup()은 전역 함수 unserialize()를 이용해서 unserialize 할 수 없도록 private 으로 제한되어 있습니다.
새 인스턴스 생성 시에는 정적 메소드인 getInstance() 내에서 지연된 정적 바인딩을 통해서 생성됩니다. static 키워드가 사용되고 있는데요, 지연된 정적 바인딩을 사용함으로써 Singleton 클래스를 상속해서 싱글턴 패턴을 사용하는 자식 클래스들을 만들 수 있게 됩니다.
웹 어플리케이션의 HTTP 요청 처리 사이클에서 특정 클래스의 인스턴스가 단 하나만 존재해야 한다는 것을 명확히 하고 싶을 때 싱글턴 패턴을 사용하면 됩니다. Configuration 클래스 같은 전역 개체나 이벤트 큐 같은 공유 리소스의 경우 통상적으로 그러한 성격을 띄는 경우가 많습니다.

싱글턴 패턴을 사용할 때 주의해야 할 것은, 패턴의 특성상 어플리케이션 전체 범위에 영향을 주는 일종의 상태 정보가 생긴다는 것입니다. 이런 특성 때문에 테스트 가능성을 떨어뜨립니다. 대부분의 경우에는 싱글턴 클래스 대신 의존성 주입(Dependency Injection)을 사용할 수 있으므로 가능하다면 싱글턴을 피하는 편이 좋을 것입니다. 의존성 주입을 사용하게 되면 공유되는 리소스를 사용하는 클래스라고 해도 구체적인 싱글턴 클래스의 구현에 의존적이지 않게 되므로 설계적으로 더 낫습니다.
*/
?>
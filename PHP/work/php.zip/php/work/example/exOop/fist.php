<?php
/*
Global Namespace : functions, classes, interfaces, constants(not class constants), variables defined outside of functions/methods

Rules : the floowing list gives an overvies of which rights the PHP project reserves for itself, when choosing names for new internal identifiers. The definitive guide is the official 
-PHP reserves all symbols starting with __as magical. it is recommended that you do not create symbols starting with __ in PHP unless you want to use documented magical functionality. [Exam)__get(), __autoload()]

Tips
*/
/*function text_global_ref(){
	global $obj;
	$obj = &new stdClass;
}

function text_global_noref(){
	global $obj;
	$obj = new stdClass;
}

text_global_ref();
var_dump($obj);
text_global_noref();
var_dump($obj);*/

/*function &get_instance_ref(){
	static $obj;

	echo 'Static object : ';
	var_dump($obj);
	if(!isset($obj)){
		//Assign a reference to statice variable
		$obj = &new stdClass;
	}
	$obj -> property++;
	return $obj;
}

function &get_instance_noref(){
	static $obj;
	echo 'Static object : ';
	var_dump($obj);
	if(!isset($obj)){
		//Asign the object to the static variable
		$obj = new stdclass;
	}
	$obj -> property++;
	return $obj;
}

$obj1 = get_instance_ref();
$still_obj1 = get_instance_ref();
echo "\n";
$obj2 = get_instance_noref();
$still_obj2 = get_instance_noref();*/

/*function foo(&$var){}
foo($a);	//$a allow null, create

$b = array();
foo($b['b']);
var_dump(array_key_exists('b', $b));	//bool(true)

$c = new StdClass;
foo($c->d);
var_dump(property_exists($c, 'd'));	//boold(true)*/

/*$bar =& new fooclass();
$foo =& find_var($bar);*/

//if you allocate reference to valiable inicialize global in function,
//that reference show only inner function. to avoid, use $GLOBALS array
/*$var1 = "Example variable";
$var2 = "";

function global_references($use_globals){
	global $var1, $var2;
	if($use_globals){
		$var2 =& $var1;	//
	}else{
		$GLOBALS["var2"] =& $var1;	
	}
}

// global_references(false);
// echo "var2 is set to '$var2'\n";	//var 2 is set to ''
global_references(true);
echo "var2 is set to '$var2'\n";	//var 2 is set to 'Example variable'*/

/*class SimpleClass{
	//definite property
	public $var = 'a default value';

	//definite method
	public function displayVar(){
		echo $this->var;
	}
}
$sipleClass = new SimpleClass();
$simpleClass ->displayVar();*/

/*class A{
	function foo(){
		if(isset($this)){
			echo '$this is defined(';
			echo get_class($this);
			echo ")\n";
		}else{
			echo "\$this is not defined.\n";
		}
	}
}

class B{
	function bar(){
		A::foo();
	}
}

$a = new A();
$a -> foo();		//$this is defined(A) 

A::foo();		////$this is not defined. 
$b = new B();		
$b -> bar();		//$this is defined(B) 

B::bar();		//$this is not defined.*/

class SimpleClass{

}

$instance = new SimpleClass();

$assigned   =  $instance;
$reference  =& $instance;

$instance->var = '$assigned will have this value';

$instance = null; // $instance and $reference become null

var_dump($instance);
echo "<br>";
var_dump($reference);
echo "<br>";
var_dump($assigned);





























?>





























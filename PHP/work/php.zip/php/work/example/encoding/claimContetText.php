<?php
/*
2주차 과제를 하며 ClaimInfo에 claim_contents가 추출되지 않는 문제가 있었다
문제발생지점을 찾느라 어려웠으나 선배의 도움으로 문제를 찾을 수 있었다.
curl에서 정보를 뽑은후, 자동적으로 글자깨지는것을 보완하는 코드를 호출하였는데
인코딩 변경 이후에  정규표현식을 정의하는데 참고한 url[$ch]정보와 다르게 줄바뀜 문자가 들어갔다
(.*?) --대신에--> ([^}]*?)로 추출 할 수 있었다.
*/
$ch = curl_init("http://ad2.shoplinker.co.kr/test/training_evaluation/test_file/json_file/5b927420cd0c7.html");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
//curl_setopt($ch, CURLOPT_HEADER, 1);
$result = curl_exec($ch);

if(function_exists('mb_detect_encoding')){
	$encType = mb_detect_encoding($result,"EUC-KR, UTF-8, ASCII");
	if($encType=="EUC-KR"){
		$result = iconv("EUC-KR", "UTF-8", $result);
	}
}else{
	echo "function not exists";
}


preg_match_all("/\"claim_contents\":\"([^{]*?)\",\"mall_name/", $result, $output_array);

$test = '{"claim_id":"","product_name":"1190877246","claim_contents":"주문번호   : 1800603018에 대한 클레임(교환접수) 입니다.주문자정보 : 김명호딜명   : 1190877246사유   : "}';

$test2 =json_decode($test,1);
echo "<xmp>";
print_r($test2['claim_contents']);
echo "<xmp>";

$pattern = '/"claim_contents":"([.\n\r]*?)","mall_name/';


?>
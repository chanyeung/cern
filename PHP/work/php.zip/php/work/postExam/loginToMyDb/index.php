<?php
/*$data = array(
	'user_id' => 'park3',
	'user_pass' => '1234',
	'user_name' => 'chanyeung',
	'user_job' => 'nemocommerce',
	'user_sex' => 'M'
);

$string = http_build_query($data);

$ch = curl_init("http://localhost/work/postExam/data.php");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);

echo '<xmp>';
print_r($result);
echo '</xmp>';*/

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="data.php" method="post">
	<input type="text" name="user_id" width="80%" placeholder="아이디를 입력해주세요"><br>
	<input type="password" name="user_pass" placeholder="비밀번호를 입력해주세요" ><br>
	<input type="text"  name="user_name" placeholder="성명을 입력해주세요" ><br>
	<input type="text" name="user_job" placeholder="직업을 입력해주세요"><br>
	<label for="male">남성</label>
	<input type="radio" name="user_sex" id="male" value="M">
	<label for="female">여성</label>
	<input type="radio" name="user_sex" id="female" value="F"><br>
	<input type="submit" name="submit" value="submit" >
</form>
</body>
</html>
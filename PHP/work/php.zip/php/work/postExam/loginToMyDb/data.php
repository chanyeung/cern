<?php
if(isset($_POST['user_id'], $_POST['user_pass'], $_POST['user_name'], $_POST['user_job'], $_POST['user_sex'])){
	$db = new Mysqli("localhost", "local_user01","pcy621","pcy_db");
	$user_id = $db->real_escape_string($_POST['user_id']);
	$user_pass = $db->real_escape_string($_POST['user_pass']);
	$user_name = $db->real_escape_string($_POST['user_name']);
	$user_job = $db->real_escape_string($_POST['user_job']);
	$user_sex = $db->real_escape_string($_POST['user_sex']);

	$query = "insert into study set user_id = '$user_id', user_pass = '$user_pass', user_name = '$user_name', user_job='$user_job', user_sex='$user_sex'";

	$db->query($query);


echo '<xmp>';
print_r($query);
echo '</xmp>';
}
?>
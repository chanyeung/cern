<?php
$contents=  file_get_contents('cat.jpg');

// $expires = 14 * 60*60*24;

header("Content-Type: image/jpeg");
// header("Content-Length: " . strlen($contents));
// header("Cache-Control: public", true);
// header("Pragma: public", true);
// header('Expires: ' . gmdate('D, d M Y H:i:s', time() + $expires) . ' GMT', true);

var_dump($contents);
exit;

?>
<?php
//로그인페이지에서 hidden되어있는 token값 가져오기
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://www.schneidersports.com/member/login.asp?c_redirect=");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);

//토큰 값 가져오기
$pass = 'a0000';
preg_match("/id=\"token\" name=\"token\" value=\"(.*?)\">/", $result, $matchArr);
$token = $matchArr[1];
$pwd = hash('sha512', $pass);

//post로 보낼 데이터 정의
$data = array(
	'token' => $token,
	'redirect' => '',
	'mainURL' => 'http://www.schneidersports.com',
	'pwd' => $pwd,
	'user_sort' => 'on',
	'id' => 'shoplink',
	'pass' => $pass,
	'name' => '',
	'orderNo' => ''
);
$data = http_build_query($data);

//ID와 비밀번호 등의 데이터를 data변수에 넣어 login_ajaxCheck.asp로 post 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://www.schneidersports.com/member/login_ajaxCheck.asp');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, './tmp/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, './tmp/cookies.txt');
// curl_setopt($ch, CURLOPT_HTTPHEADER, $header);	//헤더정보 얻기
$result = curl_exec($ch);


//loginOK.asp로 curl실행
curl_setopt($ch, CURLOPT_URL, 'http://www.schneidersports.com/member/loginOK.asp');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, './tmp/cookies.txt');
$result = curl_exec($ch);

/*로그인 성공 - > mallinmall페이지 도착 */
//mallinmall/로 curl실행
curl_setopt($ch, CURLOPT_URL, 'http://www.schneidersports.com/mallinmall/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, './tmp/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, './tmp/cookies.txt');
$result = curl_exec($ch);

/*상품 등록 페이지로 이동*/
curl_setopt($ch, CURLOPT_URL, 'http://www.schneidersports.com/mallinmall/goods/goods_reg.asp');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, './tmp/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, './tmp/cookies.txt');
$result = curl_exec($ch);


$contents=  file_get_contents('cat.jpg');
$data = '
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="menu"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="mode"

REG
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="guid"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="params"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="goodsDealerID"

shoplink
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="TimeUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="marginTemp"

20
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isSetCmoneyRate"

T
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="cmoneyRate"

1
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isCmoneySetDealer"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="dealerCmsType"

MIM
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="dealerCmsRate"

20
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="editor_img"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="itemNotifyName"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="itemNotifyData"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="IsSearchDeny"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="IsListDeny"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="goodsType"

N
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="cate_1"

12673
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="cate_2"

12686
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="cate_3"

12750
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="category"

12750
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="title"

냥이 분양합니다.
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="HeadTitle"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="subTitle"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="keyword"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="barcode"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="attv_txt"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="spec"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="volume"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="volumeUnit"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="addColumnTitle1"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="addColumnContent1"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="addColumnTitle2"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="addColumnContent2"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="brand"

4120
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgMain"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgMainMobile"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="wimgUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgWide"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="wimgUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgWide"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="wimgUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgWide"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgB"; filename="cat.jpg"
Content-Type: image/jpeg

'.$contents.'
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isImgAuto"

T
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgM"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgS"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgEtc"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgEtc"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgEtc"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isSoldOut"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isDisplay"

T
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isOnlySearch"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="marketPrice"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="cmoney"

1000
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="goodsCmsType"

CTGMIM
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="priceSplit"

MARGIN
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="price"

100,000
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="margin"

20
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="originalPrice"

80,000
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="closeprice"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="staffprice"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isTimeSet"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="TimePrice"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="TimeStartDay"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="TimeStartTime"

00
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="TimeEndDay"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="TimeEndTime"

00
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgPc"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="imgMobile"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="isMemLevelPrice"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelUid"

641
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelPrice"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelUid"

642
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelPrice"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelUid"

644
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelPrice"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelUid"

643
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelPrice"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelUid"

645
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelPrice"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelUid"

646
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="MemLevelPrice"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="product"

네모
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="placeOfOrigin"

한국
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="player"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="summary"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="content"

눈물을 머금고 개냥이 분양해요
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="goodsGubun"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="notifyName"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="notifyData"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="contentFile"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="relateGoodsUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="relateGoodsTitle"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="relateGoodsUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="relateGoodsTitle"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="relateGoodsUid"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="relateGoodsTitle"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="deliveryMethod"

920
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="deliveryContent"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkStock_type"

T
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="stock"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkOpt_useFlag"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkOPt_count"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkOpt_type"

A
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="optionTotCnt"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="optionImageTotCnt"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkAddGoods_useFlag"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="oPName"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="addProduct_count"

1
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkTextOpt_useFlag"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="oTName"


------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="optText_count"

1
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkMultiOpt_useFlag"

F
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkMultiOpt_EA"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z
Content-Disposition: form-data; name="nChkMultiOpt_Price"

0
------WebKitFormBoundaryEja9GLaOZO5gtw6z--
';



// $json = file_get_contents("./header.json");


/**/
$header2["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
$header2["Accept-Language"] = "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7";
$header2["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.92 Safari/537.36";
$header2["RefererContent-Length"] = strlen($data);
$header2["Content-Type"] = "multipart/form-data; boundary=----WebKitFormBoundaryEJA9GlAozO5gtw6z";
$header2["Referer"] = "http://www.schneidersports.com/mallinmall/goods/goods_reg.asp";
$header2["Origin"] = "http://www.schneidersports.com";
$header2["Upgrade-Insecure-Requests"] = "1";
$header2["Connection"] = "keep-alive";
$header2["Host"] = "www.schneidersports.com";


$header[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
$header[] = "Accept-Language: ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7";
$header[] = "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.92 Safari/537.36";
$header[] = "RefererContent-Length: ".strlen($data);
$header[] = "Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryEJA9GlAozO5gtw6z";
$header[] = "Referer: http://www.schneidersports.com/mallinmall/goods/goods_reg.asp";
$header[] = "Origin: http://www.schneidersports.com";
$header[] = "Upgrade-Insecure-Requests: 1";
$header[] = "Connection: keep-alive";
$header[] = "Host: www.schneidersports.com";


echo "<xmp>";
print_r($header2);
echo "\n";
print_r($header);
echo "</xmp>";
exit;

//$data_a = iconv('UTF-8','EUC-KR', $data);

curl_setopt($ch, CURLOPT_URL, 'http://www.schneidersports.com/mallinmall/goods/goods_regOk.asp');
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, './tmp/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, './tmp/cookies.txt');
$result = curl_exec($ch);

if(function_exists('mb_detect_encoding')){
	$encType = mb_detect_encoding($result,"EUC-KR, UTF-8, ASCII");
	if($encType=="EUC-KR"){
		$result = iconv("EUC-KR", "UTF-8", $result);
	}
}else{
	echo "function not exists";
}

curl_close($ch);
 
print_r($result);

exit;
?>

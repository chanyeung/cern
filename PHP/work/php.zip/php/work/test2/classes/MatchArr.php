<?php
class MatchArr{
	//regularExpresion, cURL, resultArr[arrkey][0~N]
	function __construct($pattern, $curlResult){
		$this->pattern = $pattern;
		$this->curlResult = $curlResult;
		$this->matchAll();
	}

	//reguler Express -> preg match all
	function matchAll(){
		preg_match_all($this->pattern, $this->curlResult, $this->matchArr);
	}

	//replace .comma, space&nbsp -> ""
	function getArr(){
		foreach ($this->matchArr[1] as $key => $value) {
			$value=str_replace(array(',', ' '), "", $value);
			$value=str_replace(array('""'), " ", $value);
			$this->arr[$key]=$value;
		}
		return $this->arr;
	}

	/*function mergeArr($arr1, $arr2){
		foreach ($arr1 as $key => $value) {
			if($value==""){
				$arr1[$key]=$arr2[$key];
			}
		}
		return $arr1;
	}*/

	/*function printArr($sort,$resultArr, $url){
		echo "<br><table><tr>";
		foreach ($resultArr as $key => $value) {
			echo "<td>" . $key . "</td>";	
		}
		echo "</tr>";	
		
		foreach ($resultArr[$sort] as $idx => $value) {
			echo "<tr>";
			foreach ($resultArr as $key => $keyName) {
				echo "<td>";
				if($key=="num"){
					echo "<a href=" . $url .  $resultArr[$key][$idx] . ">";
					echo $resultArr[$key][$idx] . "</a></td>";
				}else{
					echo $resultArr[$key][$idx] . "</td>";
				}
			}
			echo "</tr>";
		}	
		echo "</table>";
	}*/

	function printArr2($resultArr, $info, $mall){
		//중복된 상품가격 개수 노출, 중복된 쇼핑계 상품코드 노출	
		if($info=="ProductInfo"){
			$overlap = array_count_values($resultArr[$info]['sale_price']);

		}else if ($info == "Orderinfo") {
			$overlap = array_count_values($resultArr[$info]['mall_product_id']);
		}

		//컬럼명, 카테고리 출력
		echo "<br><table><tr>";
		foreach ($resultArr[$info] as $key => $value) {
			echo "<td>" . $key . "</td>";	
		}
		echo "</tr>";
		
		//총 합계 금액
		$count = 0;
		//쇼핑몰별, info에 해당하는 데이터 출력
		foreach ($resultArr[$info]['mall_name'] as $idx => $value) {
			// echo ">>>".$idx."<<<<br>";
			echo "<tr>";
			foreach ($resultArr[$info] as $cat => $catArr) {
				//output print by shopping mall
				if($value==$mall){
					//중복된 상품가격 개수 노출,중복된 쇼핑계 상품코드 노출	
					if(($info=="Orderinfo" & $cat=="mall_product_id")|($info=="ProductInfo"&$cat=="sale_price")){
						echo "<td>" . $resultArr[$info][$cat][$idx]."[" . $overlap[$resultArr[$info][$cat][$idx]]."]" . "</td>";
					}else{
						echo "<td>" . $resultArr[$info][$cat][$idx] . "</td>";
					}
				}
				//total Price, sum
				if($cat == "sale_price"){
					$count += $resultArr[$info][$cat][$idx];
				}
			}
			echo "</tr>";
		}	
		echo "</table>";
		
		if (isset($overlap)) {
			echo "<br>판매가 합계 = " . $count;
		}
		
	}
}
?>
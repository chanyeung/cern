<?php
include 'controller.php';

$productSize=count($resultArr['ProductInfo']['product_id']);
$orderSize=count($resultArr['Orderinfo']['order_id']);
$claimSize=count($resultArr['ClaimInfo']['claim_id']);
$csSize=count($resultArr['CsInfo']['cs_id']);

//print counts by info
echo '총 상품건수 : <a href=detailCat.php?info=ProductInfo&size=' . $productSize.'>' . count($resultArr['ProductInfo']['product_id']) . "</a><br>";
echo '총 주문건수 : <a href=detailCat.php?info=Orderinfo&size=' . $orderSize.'>' . count($resultArr['Orderinfo']['order_id']) . "</a><br>";
echo '총 클레임 건수 : <a href=detailCat.php?info=ClaimInfo&size=' . $claimSize.'>' . count($resultArr['ClaimInfo']['claim_id']) . "</a><br>";
echo '총 문의후기 건수 : <a href=detailCat.php?info=CsInfo&size=' . $csSize . '>' . count($resultArr['CsInfo']['cs_id']) . "</a><br>";
echo "<a href=home.html>home</a>";
?>
<?php
include 'input.php';
include 'style.css';

spl_autoload_register(function($class01){
	include 'classes/' . $class01 . '.php';
});
?>
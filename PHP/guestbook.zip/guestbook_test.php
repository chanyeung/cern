<?php
//dbconn.php파일을 포함시킴
include("dbconn.php");
$sql = "select * from guestbook";
//sql을 실행시킨 후 결과셋의 포인터를 rs에 전달
$rs = mysql_query($sql);
//결과셋이 없으면, A===B값이 같고 자료형도 같으면
if($rs === false){
	echo mysql_error();	//에러메시지 출력
}
//결과셋에서 레코드 1개를 꺼내어 출력
while($row = mysql_fetch_array($rs)){
	echo "$row[name] , $row[content]<br>";
}

?>
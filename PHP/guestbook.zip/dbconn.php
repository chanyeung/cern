<?php
$host = "localhost";
$user = "user01";
$passwd = "pcy621";
//mysql에 접속
$conn = mysql_connect($host, $user, $passwd);
//use 데이터베이스
mysql_select_db("pcy_db");
if($conn ==true){
	// echo "mysql에 연결되었습니다.";
}else{
	echo "db 연결 에러...";
}
?>
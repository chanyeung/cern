<!DOCTYPE html>
<?php
include("dbconn.php");
//http://ec2-54-180-74-243.ap-northeast-2.compute.amazonaws.com/php01/guestbook/view.php?idx=15
$sql = "select * from guestbook where idx =" . $_GET["idx"];
$rs = mysql_query($sql);
if($row=mysql_fetch_array($rs)){
	$name = $row["name"];
	$email = $row["email"];
	$content = $row["content"];
}
mysql_close();	//mysql 연결 종료
?>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
<script>
	function update(){
		//레코드 update 처리 주소 지정
		document.form1.action = "update.php";
		//서버로 자료 제출
		document.form1.submit();
	}
	function del() {
		if(confirm("삭제하시겠습니까?"))
		document.form1.action="delete.php";
		document.form1.submit();
	}
</script>
</head>
<body>
<h2>방명록</h2>
<form name="form1" method="post">
	<table border="1">
		<tr>
			<td>이름</td>
			<td><input name="name" value="<?php echo $name; ?>"></td>
		</tr>
		<tr>
			<td>이메일</td>
			<td><input name="email" value="<?php echo $email; ?>"></td>
		</tr>
		<tr>
			<td colspan="2">
				<textarea rows="5" cols="60" name="content"><?php echo $content; ?></textarea>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<!-- 수정, 삭제를 위해 필요한 게시물번호를 hidden 태그로 넘김 -->
				<input type="hidden" name="idx" value="<?php echo $_GET["idx"]?>">
				<input type="button" value="수정" onclick="update()">
				<input type="button" value="삭제" onclick="del()">
			</td>
		</tr>
	</table>
</form>
</body>
</html>
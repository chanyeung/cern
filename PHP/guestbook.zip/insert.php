<?php
include("dbconn.php");
//post 방식으로 전달된 변수
$name = $_POST["name"];
$email = $_POST["email"];
$content = $_POST["content"];

//작은 따옴포 처리
$name = str_replace("'", "''", $name);
$email = str_replace("'", "''", $email);
$content = str_replace("'", "\'", $content);

$sql = "insert into guestbook"
. "(name, email, content, passwd, post_date) values"
. " ('$name', '$email', '$content', '1234', now() )";
$result = mysql_query($sql);	//insert 처리 후 페이지 이동
/*if($result === false){
	echo mysql_error();
}*/
?>
<script>
	location.href = "list.php";
</script>